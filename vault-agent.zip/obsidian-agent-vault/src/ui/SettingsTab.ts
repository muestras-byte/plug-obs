import { App, PluginSettingTab, Setting } from "obsidian";
import type VaultAgentPlugin from "../main";

export class VaultAgentSettingTab extends PluginSettingTab {
	constructor(app: App, private readonly plugin: VaultAgentPlugin) {
		super(app, plugin);
	}

	display(): void {
		const { containerEl } = this;
		containerEl.empty();

		containerEl.createEl("h2", { text: "Vault Agent — Configuración" });

		new Setting(containerEl)
			.setName("Confirmar acciones destructivas")
			.setDesc("Pide confirmación antes de mover o eliminar notas.")
			.addToggle((toggle) =>
				toggle.setValue(this.plugin.settings.confirmDestructiveActions).onChange(async (value) => {
					this.plugin.settings.confirmDestructiveActions = value;
					await this.plugin.saveSettings();
				})
			);

		containerEl.createEl("p", {
			text:
				"Esta es la Fase 1 del proyecto: gestión de notas por lenguaje natural mediante reglas locales, sin conexión a ningún servicio de IA externo. Las integraciones (IA, RAG, MCP, Google, Telegram, n8n, Home Assistant) se añadirán en fases futuras aprobadas.",
		});
	}
}

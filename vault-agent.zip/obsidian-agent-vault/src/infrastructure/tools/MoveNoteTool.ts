import { App, normalizePath } from "obsidian";
import { Tool, ToolResult } from "../../domain/tools/Tool";
import { ensureFolderExists, resolveNoteFile } from "../obsidian/noteResolver";

export class MoveNoteTool implements Tool {
	readonly name = "move-note";
	readonly description = "Mueve una nota existente a otra carpeta del vault.";
	// Se marca como destructiva porque puede afectar enlaces relativos y no es reversible con un solo clic.
	readonly isDestructive = true;
	readonly parameters = [
		{ name: "title", type: "string" as const, required: true, description: "Título o ruta de la nota a mover." },
		{ name: "targetFolder", type: "string" as const, required: true, description: "Carpeta de destino." },
	];

	constructor(private readonly app: App) {}

	async execute(params: Record<string, unknown>): Promise<ToolResult> {
		const title = String(params.title ?? "").trim();
		const targetFolder = String(params.targetFolder ?? "").trim();

		const file = resolveNoteFile(this.app, title);
		if (!file) {
			return { success: false, message: `No encontré ninguna nota que coincida con "${title}".` };
		}

		try {
			await ensureFolderExists(this.app, targetFolder);
			const newPath = normalizePath(`${targetFolder}/${file.name}`);
			await this.app.vault.rename(file, newPath);
			return { success: true, message: `Nota movida a: ${newPath}`, data: { path: newPath } };
		} catch (error) {
			return { success: false, message: `No se pudo mover la nota: ${(error as Error).message}` };
		}
	}
}

import { IntentParser, ParsedIntent } from "../../domain/agent/IntentParser";

/**
 * Interpretación de lenguaje natural mediante patrones explícitos (regex),
 * sin llamadas a ningún proveedor de IA. Es intencionalmente simple y limitada:
 * cubre frases directas en español para las operaciones de Fase 1.
 *
 * Esta clase es un adaptador reemplazable: en una fase futura aprobada podrá
 * sustituirse por un IntentParser respaldado por un modelo de lenguaje (por ejemplo
 * Gemini), implementando la misma interfaz `IntentParser`, sin tocar el orquestador
 * ni las Tools.
 */
export class RuleBasedIntentParser implements IntentParser {
	parse(message: string): ParsedIntent | null {
		const text = message.trim();
		const lower = text.toLowerCase();

		// Crear nota: "crea una nota llamada X" / "crear nota X"
		let match = lower.match(/^(?:cre[a|á]|crear)\s+(?:una\s+)?nota\s+(?:llamada\s+|titulada\s+)?["“]?(.+?)["”]?$/);
		if (match) {
			const title = match[1].trim();
			return {
				toolName: "create-note",
				params: { title },
				explanation: `Crear una nueva nota llamada "${title}".`,
			};
		}

		// Leer nota: "lee la nota X" / "muéstrame la nota X" / "abre X"
		match = lower.match(/^(?:lee|leer|mu[eé]strame|abre|abrir)\s+(?:la\s+)?nota\s+["“]?(.+?)["”]?$/);
		if (match) {
			const title = match[1].trim();
			return {
				toolName: "read-note",
				params: { title },
				explanation: `Leer el contenido de la nota "${title}".`,
			};
		}

		// Mover nota: "mueve la nota X a Y" / "mover X a la carpeta Y"
		match = lower.match(/^(?:mueve|mover)\s+(?:la\s+)?nota\s+["“]?(.+?)["”]?\s+a\s+(?:la\s+carpeta\s+)?["“]?(.+?)["”]?$/);
		if (match) {
			const title = match[1].trim();
			const targetFolder = match[2].trim();
			return {
				toolName: "move-note",
				params: { title, targetFolder },
				explanation: `Mover la nota "${title}" a la carpeta "${targetFolder}".`,
			};
		}

		// Eliminar nota: "elimina la nota X" / "borrar nota X"
		match = lower.match(/^(?:elimina|eliminar|borra|borrar)\s+(?:la\s+)?nota\s+["“]?(.+?)["”]?$/);
		if (match) {
			const title = match[1].trim();
			return {
				toolName: "delete-note",
				params: { title },
				explanation: `Eliminar (mover a la papelera) la nota "${title}".`,
			};
		}

		// Frontmatter: "pon en la nota X el campo Y en Z" / "actualiza el frontmatter de X: Y = Z"
		match = lower.match(
			/^(?:pon|poner|actualiza|actualizar)\s+(?:en la nota\s+|el frontmatter de\s+)["“]?(.+?)["”]?\s*(?::|el campo)\s*["“]?(.+?)["”]?\s*(?:=|en)\s*["“]?(.+?)["”]?$/
		);
		if (match) {
			const title = match[1].trim();
			const field = match[2].trim();
			const value = match[3].trim();
			return {
				toolName: "update-frontmatter",
				params: { title, field, value },
				explanation: `Actualizar el frontmatter de "${title}": ${field} = ${value}.`,
			};
		}

		return null;
	}
}

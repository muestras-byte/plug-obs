# Changelog

## [0.1.0] - Fase 1

### Añadido
- Estructura base del plugin sobre el template oficial de Obsidian (esbuild + TypeScript estricto).
- Arquitectura por capas: `domain`, `infrastructure`, `ui`.
- `ToolRegistry` y contrato `Tool` para registrar acciones ejecutables.
- `AgentOrchestrator` con soporte para confirmación previa en acciones destructivas.
- `RuleBasedIntentParser`: interpretación de lenguaje natural por reglas (sin IA externa).
- Tools: crear, leer, mover y eliminar notas; leer/actualizar frontmatter YAML.
- Panel lateral de chat (`ChatView`) y modal de confirmación (`ConfirmModal`).
- Pestaña de configuración con toggle para exigir confirmación en acciones destructivas.
- Documentación: README, guía de instalación, guía de desarrollo, roadmap.

### Pendiente (fases futuras, sujetas a aprobación)
- Integración con un proveedor de IA (por ejemplo Gemini) como `IntentParser` alternativo.
- Soporte para Canvas, Dataview, QuickAdd, Templater, Tasks, Calendar.
- Memoria contextual y sistema de agentes múltiples.
- RAG y MCP.
- Integraciones externas: Gmail, Google Calendar/Meet/Drive/Sheets, Telegram, webhooks, n8n, Home Assistant.

import { App } from "obsidian";
import { Tool, ToolResult } from "../../domain/tools/Tool";
import { resolveNoteFile } from "../obsidian/noteResolver";

export class ReadNoteTool implements Tool {
	readonly name = "read-note";
	readonly description = "Lee y devuelve el contenido de una nota existente.";
	readonly isDestructive = false;
	readonly parameters = [
		{ name: "title", type: "string" as const, required: true, description: "Título o ruta de la nota a leer." },
	];

	constructor(private readonly app: App) {}

	async execute(params: Record<string, unknown>): Promise<ToolResult> {
		const title = String(params.title ?? "").trim();
		const file = resolveNoteFile(this.app, title);
		if (!file) {
			return { success: false, message: `No encontré ninguna nota que coincida con "${title}".` };
		}

		try {
			const content = await this.app.vault.read(file);
			return { success: true, message: `Contenido de ${file.path}:\n\n${content}`, data: { path: file.path, content } };
		} catch (error) {
			return { success: false, message: `No se pudo leer la nota: ${(error as Error).message}` };
		}
	}
}

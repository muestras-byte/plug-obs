import { ItemView, WorkspaceLeaf } from "obsidian";
import { AgentOrchestrator } from "../domain/agent/AgentOrchestrator";

export const VAULT_AGENT_VIEW_TYPE = "vault-agent-chat-view";

/**
 * Panel lateral de chat: captura mensajes en lenguaje natural del usuario
 * y los delega al AgentOrchestrator, mostrando la respuesta en un log simple.
 */
export class ChatView extends ItemView {
	private logEl!: HTMLDivElement;
	private inputEl!: HTMLInputElement;

	constructor(leaf: WorkspaceLeaf, private readonly orchestrator: AgentOrchestrator) {
		super(leaf);
	}

	getViewType(): string {
		return VAULT_AGENT_VIEW_TYPE;
	}

	getDisplayText(): string {
		return "Vault Agent";
	}

	getIcon(): string {
		return "bot";
	}

	async onOpen(): Promise<void> {
		const container = this.contentEl;
		container.empty();
		container.addClass("vault-agent-chat-container");

		this.logEl = container.createDiv({ cls: "vault-agent-log" });
		this.appendMessage(
			"agent",
			'Hola. Puedo crear, leer, mover y eliminar notas, y actualizar su frontmatter. Ejemplo: "crea una nota llamada Ideas".'
		);

		const inputRow = container.createDiv({ cls: "vault-agent-input-row" });
		this.inputEl = inputRow.createEl("input", {
			type: "text",
			attr: { placeholder: "Escribí una instrucción..." },
		});
		const sendButton = inputRow.createEl("button", { text: "Enviar" });

		const send = () => {
			void this.handleSend();
		};
		sendButton.addEventListener("click", send);
		this.inputEl.addEventListener("keydown", (evt: KeyboardEvent) => {
			if (evt.key === "Enter") {
				send();
			}
		});
	}

	async onClose(): Promise<void> {
		this.contentEl.empty();
	}

	private async handleSend(): Promise<void> {
		const message = this.inputEl.value.trim();
		if (message.length === 0) {
			return;
		}
		this.inputEl.value = "";
		this.appendMessage("user", message);

		const response = await this.orchestrator.handleMessage(message);
		this.appendMessage(response.understood && response.result?.success !== false ? "agent" : "error", response.message);
	}

	private appendMessage(kind: "user" | "agent" | "error", text: string): void {
		const cls =
			kind === "user"
				? "vault-agent-message vault-agent-message-user"
				: kind === "error"
				? "vault-agent-message vault-agent-message-error"
				: "vault-agent-message vault-agent-message-agent";
		const el = this.logEl.createDiv({ cls });
		el.setText(text);
		this.logEl.scrollTop = this.logEl.scrollHeight;
	}
}

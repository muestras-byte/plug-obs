/**
 * Configuración persistida del plugin (guardada vía Plugin.saveData / loadData
 * en data.json, gestionado automáticamente por Obsidian dentro del vault).
 *
 * Nota de seguridad: en esta Fase 1 no se almacena ninguna credencial ni API key,
 * ya que no hay integraciones externas todavía. Cuando se añadan (Gemini, Google,
 * Telegram, etc.) en fases futuras aprobadas, deberán guardarse cifradas o, como
 * mínimo, nunca en texto plano dentro de este objeto de settings.
 */
export interface VaultAgentSettings {
	/** Pide confirmación antes de ejecutar cualquier acción marcada como destructiva. */
	confirmDestructiveActions: boolean;
}

export const DEFAULT_SETTINGS: VaultAgentSettings = {
	confirmDestructiveActions: true,
};

import { App, Modal, Setting } from "obsidian";

/**
 * Modal simple de confirmación sí/no. Se usa para cumplir el requisito de
 * seguridad: toda acción destructiva debe pedir confirmación explícita.
 */
export class ConfirmModal extends Modal {
	private resolvePromise: ((value: boolean) => void) | null = null;

	constructor(app: App, private readonly message: string) {
		super(app);
	}

	waitForChoice(): Promise<boolean> {
		return new Promise((resolve) => {
			this.resolvePromise = resolve;
			this.open();
		});
	}

	onOpen(): void {
		const { contentEl } = this;
		contentEl.empty();

		const body = contentEl.createDiv({ cls: "vault-agent-confirm-body" });
		body.createEl("p", { text: this.message });

		new Setting(contentEl)
			.addButton((btn) =>
				btn
					.setButtonText("Cancelar")
					.onClick(() => {
						this.finish(false);
					})
			)
			.addButton((btn) =>
				btn
					.setButtonText("Confirmar")
					.setWarning()
					.onClick(() => {
						this.finish(true);
					})
			);
	}

	onClose(): void {
		this.contentEl.empty();
		// Si el usuario cierra el modal sin elegir un botón, se interpreta como cancelación.
		this.finish(false);
	}

	private finish(value: boolean): void {
		if (this.resolvePromise) {
			this.resolvePromise(value);
			this.resolvePromise = null;
		}
		this.close();
	}
}

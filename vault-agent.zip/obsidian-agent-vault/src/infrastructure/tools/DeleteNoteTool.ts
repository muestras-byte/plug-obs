import { App } from "obsidian";
import { Tool, ToolResult } from "../../domain/tools/Tool";
import { resolveNoteFile } from "../obsidian/noteResolver";

export class DeleteNoteTool implements Tool {
	readonly name = "delete-note";
	readonly description = "Elimina una nota moviéndola a la papelera del sistema/vault.";
	readonly isDestructive = true;
	readonly parameters = [
		{ name: "title", type: "string" as const, required: true, description: "Título o ruta de la nota a eliminar." },
	];

	constructor(private readonly app: App) {}

	async execute(params: Record<string, unknown>): Promise<ToolResult> {
		const title = String(params.title ?? "").trim();
		const file = resolveNoteFile(this.app, title);
		if (!file) {
			return { success: false, message: `No encontré ninguna nota que coincida con "${title}".` };
		}

		try {
			// `trash(file, true)` intenta usar la papelera del sistema operativo;
			// Obsidian cae automáticamente a la papelera interna del vault si no está disponible.
			await this.app.vault.trash(file, true);
			return { success: true, message: `Nota enviada a la papelera: ${file.path}` };
		} catch (error) {
			return { success: false, message: `No se pudo eliminar la nota: ${(error as Error).message}` };
		}
	}
}

# Guía de instalación local

Este proyecto se generó y revisó fuera de un entorno con acceso a npm/GitHub, así que la compilación debe hacerse en tu máquina. Pasos:

## 1. Requisitos

- Node.js 18 o superior (`node --version`).
- Un vault de Obsidian ya creado.

## 2. Instalar dependencias

Desde la carpeta del proyecto:

```bash
npm install
```

## 3. Compilar

Para una build de producción (minificada, sin sourcemaps):

```bash
npm run build
```

Esto genera `main.js` en la raíz del proyecto. Si preferís desarrollo con recompilación automática al guardar cambios:

```bash
npm run dev
```

## 4. Copiar el plugin al vault

Creá la carpeta del plugin dentro de tu vault (si no existe) y copiá los 3 archivos necesarios:

```bash
mkdir -p /ruta/a/tu/vault/.obsidian/plugins/vault-agent
cp main.js manifest.json styles.css /ruta/a/tu/vault/.obsidian/plugins/vault-agent/
```

## 5. Activar el plugin en Obsidian

1. Abrí Obsidian con ese vault.
2. Andá a **Configuración → Community plugins**.
3. Si es la primera vez, asegurate de que "Restringir modo seguro" esté desactivado para plugins de la comunidad instalados manualmente (Community plugins habilitado).
4. Buscá **Vault Agent** en la lista y activalo.
5. Debería aparecer un ícono de robot en la barra lateral izquierda: al hacer clic se abre el panel de chat.

## 6. Verificación

- Escribí `crea una nota llamada Prueba` en el panel y confirmá que aparece `Prueba.md` en el vault.
- Escribí `elimina la nota Prueba`: debe pedir confirmación antes de moverla a la papelera.

Si algo falla al cargar el plugin, revisá la consola de desarrollador de Obsidian (Ctrl/Cmd+Shift+I) para ver el error exacto — no debería haber ninguno si `npm run build` terminó sin errores de TypeScript.

import { Plugin, WorkspaceLeaf } from "obsidian";

import { ToolRegistry } from "./domain/tools/ToolRegistry";
import { AgentOrchestrator } from "./domain/agent/AgentOrchestrator";
import { RuleBasedIntentParser } from "./infrastructure/agent/RuleBasedIntentParser";

import { CreateNoteTool } from "./infrastructure/tools/CreateNoteTool";
import { ReadNoteTool } from "./infrastructure/tools/ReadNoteTool";
import { MoveNoteTool } from "./infrastructure/tools/MoveNoteTool";
import { DeleteNoteTool } from "./infrastructure/tools/DeleteNoteTool";
import { UpdateFrontmatterTool } from "./infrastructure/tools/UpdateFrontmatterTool";

import { ChatView, VAULT_AGENT_VIEW_TYPE } from "./ui/ChatView";
import { ConfirmModal } from "./ui/ConfirmModal";
import { VaultAgentSettingTab } from "./ui/SettingsTab";
import { DEFAULT_SETTINGS, VaultAgentSettings } from "./settings";

export default class VaultAgentPlugin extends Plugin {
	settings: VaultAgentSettings = DEFAULT_SETTINGS;
	private orchestrator!: AgentOrchestrator;

	async onload(): Promise<void> {
		await this.loadSettings();

		const toolRegistry = new ToolRegistry();
		toolRegistry.register(new CreateNoteTool(this.app));
		toolRegistry.register(new ReadNoteTool(this.app));
		toolRegistry.register(new MoveNoteTool(this.app));
		toolRegistry.register(new DeleteNoteTool(this.app));
		toolRegistry.register(new UpdateFrontmatterTool(this.app));

		const intentParser = new RuleBasedIntentParser();

		this.orchestrator = new AgentOrchestrator(toolRegistry, intentParser, async (message: string) => {
			if (!this.settings.confirmDestructiveActions) {
				return true;
			}
			return new ConfirmModal(this.app, message).waitForChoice();
		});

		this.registerView(VAULT_AGENT_VIEW_TYPE, (leaf) => new ChatView(leaf, this.orchestrator));

		this.addRibbonIcon("bot", "Abrir Vault Agent", () => {
			void this.activateChatView();
		});

		this.addCommand({
			id: "open-vault-agent-chat",
			name: "Abrir panel de Vault Agent",
			callback: () => {
				void this.activateChatView();
			},
		});

		this.addSettingTab(new VaultAgentSettingTab(this.app, this));
	}

	onunload(): void {
		this.app.workspace.getLeavesOfType(VAULT_AGENT_VIEW_TYPE).forEach((leaf) => leaf.detach());
	}

	private async activateChatView(): Promise<void> {
		const existing = this.app.workspace.getLeavesOfType(VAULT_AGENT_VIEW_TYPE);
		let leaf: WorkspaceLeaf;

		if (existing.length > 0) {
			leaf = existing[0];
		} else {
			const newLeaf = this.app.workspace.getRightLeaf(false);
			if (!newLeaf) {
				return;
			}
			leaf = newLeaf;
			await leaf.setViewState({ type: VAULT_AGENT_VIEW_TYPE, active: true });
		}

		await this.app.workspace.revealLeaf(leaf);
	}

	async loadSettings(): Promise<void> {
		this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
	}

	async saveSettings(): Promise<void> {
		await this.saveData(this.settings);
	}
}

# Vault Agent — Fase 1

Plugin de Obsidian que permite **crear, leer, mover y eliminar notas**, y **leer/actualizar su frontmatter YAML**, dando instrucciones en lenguaje natural (español) desde un panel lateral de chat.

Esta es la **Fase 1** de un proyecto más amplio (ver `docs/ROADMAP.md`). No incluye todavía IA externa, RAG, MCP, Canvas, Dataview, QuickAdd, Templater, Tasks, Calendar ni integraciones con Gmail/Google/Telegram/n8n/Home Assistant. La arquitectura está diseñada para añadir todo eso sin reescribir el core.

## Qué hace hoy

Desde el panel "Vault Agent" (icono de robot en la barra lateral, o comando "Abrir panel de Vault Agent") podés escribir instrucciones como:

- `crea una nota llamada Ideas`
- `lee la nota Ideas`
- `mueve la nota Ideas a Proyectos`
- `elimina la nota Ideas`
- `actualiza el frontmatter de Ideas: estado en pendiente`

Las acciones que mueven o eliminan notas piden **confirmación explícita** antes de ejecutarse (configurable en Ajustes).

## Arquitectura

```
src/
  domain/            # Reglas de negocio puras, sin dependencias de Obsidian
    tools/            # Contrato Tool + ToolRegistry
    agent/            # AgentOrchestrator + contrato IntentParser
  infrastructure/     # Adaptadores concretos
    agent/            # RuleBasedIntentParser (Fase 1, basado en reglas)
    obsidian/         # Helpers sobre la Vault API real
    tools/            # Tools concretas (crear/leer/mover/eliminar nota, frontmatter)
  ui/                 # ChatView, ConfirmModal, SettingsTab
  main.ts             # Composition root: conecta todas las piezas
```

Principios aplicados: Clean Architecture (dominio sin dependencias externas), inyección de dependencias, una Tool nueva = un archivo nuevo sin tocar el orquestador (abierto/cerrado), separación estricta entre "qué se entiende" (IntentParser) y "qué se ejecuta" (Tool).

## Instalación local

Ver `docs/INSTALL.md`.

## Desarrollo

Ver `docs/DEVELOPMENT.md`.

## Roadmap

Ver `docs/ROADMAP.md` para las fases futuras (IA, integraciones) pendientes de aprobación.

## Seguridad

- Las acciones destructivas (mover, eliminar) piden confirmación.
- Eliminar una nota la envía a la papelera (`vault.trash`), no la borra de forma irreversible.
- No se almacena ninguna credencial en esta fase; cuando se agreguen integraciones externas, no se guardarán en texto plano.

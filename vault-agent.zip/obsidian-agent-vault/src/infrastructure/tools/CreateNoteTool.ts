import { App, normalizePath } from "obsidian";
import { Tool, ToolResult } from "../../domain/tools/Tool";

export class CreateNoteTool implements Tool {
	readonly name = "create-note";
	readonly description = "Crea una nueva nota en el vault con un título dado.";
	readonly isDestructive = false;
	readonly parameters = [
		{ name: "title", type: "string" as const, required: true, description: "Título de la nota a crear." },
		{ name: "content", type: "string" as const, required: false, description: "Contenido inicial de la nota." },
	];

	constructor(private readonly app: App) {}

	async execute(params: Record<string, unknown>): Promise<ToolResult> {
		const title = String(params.title ?? "").trim();
		if (title.length === 0) {
			return { success: false, message: "El título de la nota no puede estar vacío." };
		}

		const content = typeof params.content === "string" ? params.content : "";
		const path = normalizePath(title.endsWith(".md") ? title : `${title}.md`);

		const existing = this.app.vault.getAbstractFileByPath(path);
		if (existing) {
			return { success: false, message: `Ya existe una nota en "${path}".` };
		}

		try {
			const file = await this.app.vault.create(path, content);
			return { success: true, message: `Nota creada: ${file.path}`, data: { path: file.path } };
		} catch (error) {
			return { success: false, message: `No se pudo crear la nota: ${(error as Error).message}` };
		}
	}
}

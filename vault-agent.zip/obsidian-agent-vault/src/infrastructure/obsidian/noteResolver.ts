import { App, TFile, normalizePath } from "obsidian";

/**
 * Resuelve un "título" dado por el usuario (con o sin extensión, con o sin ruta)
 * al TFile correspondiente en el vault. Devuelve null si no se encuentra o si
 * el path resuelto no corresponde a un archivo (por ejemplo, es una carpeta).
 */
export function resolveNoteFile(app: App, title: string): TFile | null {
	const withExtension = title.endsWith(".md") ? title : `${title}.md`;
	const normalized = normalizePath(withExtension);

	const direct = app.vault.getAbstractFileByPath(normalized);
	if (direct instanceof TFile) {
		return direct;
	}

	// Búsqueda por nombre de archivo en todo el vault si no se dio una ruta exacta.
	const candidates = app.vault.getMarkdownFiles().filter((f) => f.name === withExtension || f.basename === title);
	if (candidates.length === 1) {
		return candidates[0];
	}

	return null;
}

/** Normaliza un path de carpeta para asegurarse de que exista antes de usarlo. */
export async function ensureFolderExists(app: App, folderPath: string): Promise<void> {
	const normalized = normalizePath(folderPath);
	if (normalized.length === 0) {
		return;
	}
	const existing = app.vault.getAbstractFileByPath(normalized);
	if (!existing) {
		await app.vault.createFolder(normalized);
	}
}

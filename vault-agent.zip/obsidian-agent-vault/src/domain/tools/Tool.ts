/**
 * Contrato que debe cumplir cualquier acción ejecutable por el agente.
 * Esta interfaz vive en la capa de dominio: no depende de la API de Obsidian
 * ni de ningún proveedor de IA concreto, para poder testearse de forma aislada
 * y para permitir añadir nuevas herramientas (Canvas, Dataview, Telegram, n8n, etc.)
 * sin modificar el orquestador ni el resto del core.
 */

/** Resultado uniforme que devuelve toda Tool tras ejecutarse. */
export interface ToolResult {
	success: boolean;
	message: string;
	/** Datos estructurados opcionales, útiles para encadenar acciones o mostrarlos en la UI. */
	data?: unknown;
}

/** Descripción de un parámetro esperado por una Tool, usada para validación y documentación. */
export interface ToolParameterSchema {
	name: string;
	type: "string" | "number" | "boolean";
	required: boolean;
	description: string;
}

/**
 * Una Tool es una unidad de trabajo autocontenida (crear nota, mover nota, etc.).
 * `isDestructive` permite que capas superiores (UI, orquestador) exijan confirmación
 * antes de ejecutar, cumpliendo el requisito de seguridad del proyecto.
 */
export interface Tool {
	readonly name: string;
	readonly description: string;
	readonly parameters: ToolParameterSchema[];
	readonly isDestructive: boolean;

	execute(params: Record<string, unknown>): Promise<ToolResult>;
}

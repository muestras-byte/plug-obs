/** Intención reconocida a partir de un mensaje en lenguaje natural. */
export interface ParsedIntent {
	/** Nombre de la Tool que debe ejecutarse (debe existir en el ToolRegistry). */
	toolName: string;
	/** Parámetros extraídos del mensaje para pasar a la Tool. */
	params: Record<string, unknown>;
	/** Texto explicativo de qué se entendió, para mostrar al usuario antes de ejecutar. */
	explanation: string;
}

/**
 * Estrategia de interpretación de lenguaje natural. En la Fase 1 se implementa
 * mediante reglas/patrones (sin llamadas a APIs externas de IA). El diseño permite
 * sustituir esta implementación por un IntentParser basado en un modelo de lenguaje
 * (Gemini, etc.) en una fase futura aprobada, sin modificar el AgentOrchestrator.
 */
export interface IntentParser {
	/**
	 * Intenta interpretar el mensaje. Devuelve `null` si no reconoce ninguna
	 * intención soportada, para que la capa superior informe al usuario en vez
	 * de inventar una acción.
	 */
	parse(message: string): ParsedIntent | null;
}

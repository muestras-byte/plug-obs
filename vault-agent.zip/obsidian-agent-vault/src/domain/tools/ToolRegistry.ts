import { Tool } from "./Tool";

/**
 * Punto único de extensión del sistema: cada nueva capacidad (Canvas, Dataview,
 * QuickAdd, Telegram, n8n, Home Assistant, etc.) se añade registrando aquí una
 * nueva Tool, sin tocar el orquestador ni el core del plugin (principio abierto/cerrado).
 */
export class ToolRegistry {
	private readonly tools = new Map<string, Tool>();

	register(tool: Tool): void {
		if (this.tools.has(tool.name)) {
			throw new Error(`Ya existe una Tool registrada con el nombre "${tool.name}".`);
		}
		this.tools.set(tool.name, tool);
	}

	get(name: string): Tool | undefined {
		return this.tools.get(name);
	}

	list(): Tool[] {
		return Array.from(this.tools.values());
	}

	has(name: string): boolean {
		return this.tools.has(name);
	}
}

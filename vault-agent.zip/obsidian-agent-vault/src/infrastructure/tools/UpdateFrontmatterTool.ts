import { App } from "obsidian";
import { Tool, ToolResult } from "../../domain/tools/Tool";
import { resolveNoteFile } from "../obsidian/noteResolver";

export class UpdateFrontmatterTool implements Tool {
	readonly name = "update-frontmatter";
	readonly description = "Crea o actualiza un campo del frontmatter (YAML) de una nota.";
	readonly isDestructive = false;
	readonly parameters = [
		{ name: "title", type: "string" as const, required: true, description: "Título o ruta de la nota." },
		{ name: "field", type: "string" as const, required: true, description: "Nombre del campo YAML." },
		{ name: "value", type: "string" as const, required: true, description: "Valor a asignar al campo." },
	];

	constructor(private readonly app: App) {}

	async execute(params: Record<string, unknown>): Promise<ToolResult> {
		const title = String(params.title ?? "").trim();
		const field = String(params.field ?? "").trim();
		const value = String(params.value ?? "").trim();

		const file = resolveNoteFile(this.app, title);
		if (!file) {
			return { success: false, message: `No encontré ninguna nota que coincida con "${title}".` };
		}
		if (field.length === 0) {
			return { success: false, message: "El nombre del campo no puede estar vacío." };
		}

		try {
			await this.app.fileManager.processFrontMatter(file, (frontmatter: Record<string, unknown>) => {
				frontmatter[field] = value;
			});
			return { success: true, message: `Frontmatter actualizado en ${file.path}: ${field} = ${value}` };
		} catch (error) {
			return { success: false, message: `No se pudo actualizar el frontmatter: ${(error as Error).message}` };
		}
	}
}

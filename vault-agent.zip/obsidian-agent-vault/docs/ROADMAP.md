# Roadmap (pendiente de aprobación fase por fase)

Este documento refleja el alcance original del proyecto, dividido en fases incrementales. Cada fase se implementa solo tras aprobación explícita, y cada una debe dejar el proyecto compilando y sin romper lo ya aprobado.

## Fase 1 — Completada
Núcleo del plugin + gestión de notas por lenguaje natural (crear, leer, mover, eliminar, frontmatter YAML), sin IA externa.

## Fase 2 — Propuesta (no iniciada)
- Integración con un proveedor de IA (por ejemplo, Gemini API) como `IntentParser` alternativo, para entender instrucciones más flexibles que las reglas actuales.
- Requiere: definir de dónde sale la API key (nunca en texto plano), y confirmar los endpoints/SDK reales antes de escribir código contra ellos.

## Fase 3 — Propuesta (no iniciada)
- Soporte para Canvas, Dataview, QuickAdd, Templater, Tasks, Calendar — como Tools adicionales que se apoyan en los plugins/APIs correspondientes cuando estén instalados.
- Requiere confirmar qué API pública expone cada uno de esos plugins (no todos tienen una API estable documentada).

## Fase 4 — Propuesta (no iniciada)
- Memoria contextual entre conversaciones y sistema de múltiples agentes.

## Fase 5 — Propuesta (no iniciada)
- RAG sobre el contenido del vault.
- MCP (Model Context Protocol) como cliente y/o servidor.

## Fase 6 — Propuesta (no iniciada)
- Integraciones externas: Gmail, Google Calendar, Google Meet, Google Drive, Google Sheets, Telegram, webhooks, n8n, Home Assistant.
- Cada integración implica manejo de OAuth/tokens propio y credenciales reales que debe aportar quien las use; ninguna de estas integraciones puede probarse ni validarse sin esas credenciales.

Ninguna fase posterior a la 1 está implementada todavía.

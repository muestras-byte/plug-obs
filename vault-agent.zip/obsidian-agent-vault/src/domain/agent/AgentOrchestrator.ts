import { ToolRegistry } from "../tools/ToolRegistry";
import { ToolResult } from "../tools/Tool";
import { IntentParser } from "./IntentParser";

/**
 * Función que la capa de UI debe proveer para pedir confirmación al usuario
 * antes de ejecutar una acción destructiva. Mantiene el dominio desacoplado
 * de cualquier detalle de Obsidian (Modal, etc.).
 */
export type ConfirmationRequester = (message: string) => Promise<boolean>;

export interface AgentResponse {
	understood: boolean;
	message: string;
	result?: ToolResult;
}

/**
 * Coordina el flujo: lenguaje natural -> intención -> (confirmación si aplica) -> ejecución.
 * No conoce Obsidian ni ningún proveedor de IA concreto: ambos se inyectan por interfaz,
 * lo que permite testear el orquestador de forma aislada y sustituir piezas sin romper el resto.
 */
export class AgentOrchestrator {
	constructor(
		private readonly toolRegistry: ToolRegistry,
		private readonly intentParser: IntentParser,
		private readonly requestConfirmation: ConfirmationRequester
	) {}

	async handleMessage(message: string): Promise<AgentResponse> {
		const trimmed = message.trim();
		if (trimmed.length === 0) {
			return { understood: false, message: "El mensaje está vacío." };
		}

		const intent = this.intentParser.parse(trimmed);
		if (!intent) {
			return {
				understood: false,
				message:
					"No entendí esa instrucción. Por ahora puedo crear, leer, editar, mover o eliminar notas, y leer/actualizar su frontmatter YAML.",
			};
		}

		const tool = this.toolRegistry.get(intent.toolName);
		if (!tool) {
			return {
				understood: false,
				message: `Se reconoció la intención "${intent.toolName}" pero no hay ninguna Tool registrada para ejecutarla.`,
			};
		}

		if (tool.isDestructive) {
			const confirmed = await this.requestConfirmation(
				`${intent.explanation}\n\n¿Confirmás esta acción? No se puede deshacer fácilmente.`
			);
			if (!confirmed) {
				return { understood: true, message: "Acción cancelada por el usuario." };
			}
		}

		const result = await tool.execute(intent.params);
		return { understood: true, message: result.message, result };
	}
}

# Guía para desarrolladores

## Cómo añadir una nueva Tool

1. Crear una clase en `src/infrastructure/tools/` que implemente la interfaz `Tool` (`src/domain/tools/Tool.ts`).
2. Registrarla en `src/main.ts` dentro de `onload()`, con `toolRegistry.register(new MiNuevaTool(this.app))`.
3. Si la acción es irreversible o puede causar pérdida de datos, marcar `isDestructive = true`: el `AgentOrchestrator` pedirá confirmación automáticamente antes de ejecutarla.
4. Si querés que se dispare desde lenguaje natural, añadir un patrón nuevo en `RuleBasedIntentParser` (`src/infrastructure/agent/RuleBasedIntentParser.ts`) que devuelva `{ toolName: "mi-nueva-tool", params: {...}, explanation: "..." }`.

No hace falta tocar `AgentOrchestrator` ni `ChatView` para agregar funcionalidad nueva: ese es el punto del diseño (principio abierto/cerrado).

## Cómo se conectaría un proveedor de IA en el futuro

`RuleBasedIntentParser` implementa la interfaz `IntentParser`. Para sustituirla por un parser respaldado por un modelo de lenguaje:

1. Crear `src/infrastructure/agent/LLMIntentParser.ts` implementando `IntentParser`.
2. En `main.ts`, cambiar `new RuleBasedIntentParser()` por `new LLMIntentParser(...)`.
3. El `AgentOrchestrator` no cambia: solo depende de la interfaz `IntentParser`, no de la implementación concreta.

Esto es intencional y está pendiente de aprobación como fase futura — no se implementa todavía para no incorporar dependencias externas ni suposiciones sobre APIs no confirmadas.

## Convenciones de código

- TypeScript estricto (`strict: true`, `noUnusedLocals`, `noUnusedParameters` en `tsconfig.json`).
- El dominio (`src/domain`) no debe importar nada de `obsidian`. Toda dependencia de la API real vive en `src/infrastructure`.
- Cada `Tool` debe devolver siempre un `ToolResult` (`success`, `message`, `data?`), nunca lanzar excepciones sin capturarlas.
- Usar `normalizePath` de Obsidian para cualquier ruta construida manualmente, para evitar problemas de separadores entre sistemas operativos.

## Scripts

- `npm run dev`: build con watch mode (sourcemaps inline, sin minificar).
- `npm run build`: type-check estricto (`tsc -noEmit`) + build de producción minificada.
- `npm version patch|minor|major`: sincroniza versión en `package.json`, `manifest.json` y `versions.json`.
